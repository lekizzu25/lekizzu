import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule } from '@nestjs/throttler';
import { ScheduleModule } from '@nestjs/schedule';
import { AuthModule } from './modules/auth/auth.module';
import { ShopsModule } from './modules/shops/shops.module';
import { PosModule } from './modules/pos/pos.module';
import { InventoryModule } from './modules/inventory/inventory.module';
import { CustomersModule } from './modules/customers/customers.module';
import { AppointmentsModule } from './modules/appointments/appointments.module';
import { TailorOrdersModule } from './modules/tailor-orders/tailor-orders.module';
import { MessagingModule } from './modules/messaging/messaging.module';
import { SubscriptionsModule } from './modules/subscriptions/subscriptions.module';
import { ReportsModule } from './modules/reports/reports.module';
import { SupabaseModule } from './common/supabase/supabase.module';

@Module({
  imports: [
    // Config — loads .env
    ConfigModule.forRoot({ isGlobal: true }),

    // Rate limiting: 100 req / 60s per IP
    ThrottlerModule.forRoot([{ ttl: 60000, limit: 100 }]),

    // Cron jobs (appointment reminders, message queue)
    ScheduleModule.forRoot(),

    // Shared Supabase client
    SupabaseModule,

    // Feature modules
    AuthModule,
    ShopsModule,
    PosModule,
    InventoryModule,
    CustomersModule,
    AppointmentsModule,
    TailorOrdersModule,
    MessagingModule,
    SubscriptionsModule,
    ReportsModule,
  ],
})
export class AppModule {}

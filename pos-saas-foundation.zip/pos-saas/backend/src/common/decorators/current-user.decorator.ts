import { createParamDecorator, ExecutionContext } from '@nestjs/common';

export interface AuthUser {
  id: string;
  shop_id: string;
  role: 'owner' | 'employee' | 'admin';
  name: string;
  auth_id: string;
}

/**
 * Injects the authenticated user from request.
 * Usage: @CurrentUser() user: AuthUser
 */
export const CurrentUser = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext): AuthUser => {
    const request = ctx.switchToHttp().getRequest();
    return request.user;
  },
);

/**
 * Injects just the shop_id — most common use case.
 * Usage: @CurrentShop() shopId: string
 */
export const CurrentShop = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext): string => {
    const request = ctx.switchToHttp().getRequest();
    return request.user?.shop_id;
  },
);

import { Injectable, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

@Injectable()
export class SupabaseService implements OnModuleInit {
  private client: SupabaseClient;

  constructor(private config: ConfigService) {}

  onModuleInit() {
    const url = this.config.getOrThrow<string>('SUPABASE_URL');
    const key = this.config.getOrThrow<string>('SUPABASE_SERVICE_ROLE_KEY');

    // Service role key bypasses RLS — safe for server-side use only
    this.client = createClient(url, key, {
      auth: { autoRefreshToken: false, persistSession: false },
    });
  }

  get db(): SupabaseClient {
    return this.client;
  }

  // Typed table helper — usage: this.supabase.from('sales')
  from(table: string) {
    return this.client.from(table);
  }

  // Auth admin helpers
  get auth() {
    return this.client.auth.admin;
  }
}

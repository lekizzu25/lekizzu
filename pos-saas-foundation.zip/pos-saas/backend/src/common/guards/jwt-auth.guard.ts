// jwt-auth.guard.ts
import {
  Injectable,
  CanActivate,
  ExecutionContext,
  UnauthorizedException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createClient } from '@supabase/supabase-js';

/**
 * Validates the Supabase JWT from Authorization header.
 * On success, injects req.user = { id, shop_id, role }
 * Every protected route gets shop_id for free — no manual passing needed.
 */
@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(private config: ConfigService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const authHeader = request.headers['authorization'];

    if (!authHeader?.startsWith('Bearer ')) {
      throw new UnauthorizedException('Missing authorization token');
    }

    const token = authHeader.split(' ')[1];

    // Verify token with Supabase anon key (validates JWT signature)
    const supabase = createClient(
      this.config.getOrThrow('SUPABASE_URL'),
      this.config.getOrThrow('SUPABASE_ANON_KEY'),
    );

    const { data: { user }, error } = await supabase.auth.getUser(token);

    if (error || !user) {
      throw new UnauthorizedException('Invalid or expired token');
    }

    // Fetch user record with shop_id and role from our users table
    const adminClient = createClient(
      this.config.getOrThrow('SUPABASE_URL'),
      this.config.getOrThrow('SUPABASE_SERVICE_ROLE_KEY'),
    );

    const { data: dbUser, error: dbError } = await adminClient
      .from('users')
      .select('id, shop_id, role, name, is_active')
      .eq('auth_id', user.id)
      .single();

    if (dbError || !dbUser) {
      throw new UnauthorizedException('User not found in system');
    }

    if (!dbUser.is_active) {
      throw new UnauthorizedException('Account is deactivated');
    }

    // Inject into request — available in all controllers via @CurrentUser()
    request.user = {
      id: dbUser.id,
      shop_id: dbUser.shop_id,
      role: dbUser.role,
      name: dbUser.name,
      auth_id: user.id,
    };

    return true;
  }
}

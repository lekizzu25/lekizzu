import {
  Injectable,
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  SetMetadata,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { SupabaseService } from '../supabase/supabase.service';

export const REQUIRED_MODULE = 'required_module';
export const RequireModule = (module: string) =>
  SetMetadata(REQUIRED_MODULE, module);

/**
 * Checks that the shop has the required module enabled.
 * Usage: @RequireModule('inventory') on controller or route
 *
 * enabled_modules on shops table: ["pos","inventory","credit","appointments"]
 */
@Injectable()
export class ModuleGuard implements CanActivate {
  constructor(
    private reflector: Reflector,
    private supabase: SupabaseService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const requiredModule = this.reflector.getAllAndOverride<string>(
      REQUIRED_MODULE,
      [context.getHandler(), context.getClass()],
    );

    // No module requirement = open to all
    if (!requiredModule) return true;

    const request = context.switchToHttp().getRequest();
    const shopId = request.user?.shop_id;
    if (!shopId) return false;

    const { data: shop } = await this.supabase
      .from('shops')
      .select('enabled_modules, is_active')
      .eq('id', shopId)
      .single();

    if (!shop?.is_active) {
      throw new ForbiddenException('Shop account is inactive');
    }

    const modules: string[] = shop.enabled_modules || [];

    if (!modules.includes(requiredModule)) {
      throw new ForbiddenException(
        `Module "${requiredModule}" is not enabled on your plan. Please upgrade.`,
      );
    }

    return true;
  }
}

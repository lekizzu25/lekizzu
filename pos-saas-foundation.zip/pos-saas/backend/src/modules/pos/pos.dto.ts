// ============================================================
// POS Module — Checkout, Sales, Receipts
// ============================================================

// --- pos.module.ts ---
import { Module } from '@nestjs/common';
import { PosController } from './pos.controller';
import { PosService } from './pos.service';
import { MessagingModule } from '../messaging/messaging.module';

// Export as module (placed at bottom of file)


// --- DTOs ---
import {
  IsUUID, IsOptional, IsArray, ValidateNested,
  IsNumber, IsString, IsEnum, Min, IsPositive,
} from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class SaleItemDto {
  @ApiProperty() @IsUUID() product_id: string;
  @ApiProperty() @IsNumber() @IsPositive() quantity: number;
  @ApiProperty() @IsNumber() @Min(0) unit_price: number;
  @ApiPropertyOptional() @IsOptional() @IsNumber() @Min(0) discount?: number;
}

export class CreateSaleDto {
  @ApiPropertyOptional() @IsOptional() @IsUUID() customer_id?: string;
  @ApiProperty({ type: [SaleItemDto] })
  @IsArray() @ValidateNested({ each: true }) @Type(() => SaleItemDto)
  items: SaleItemDto[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsEnum(['cash', 'card', 'transfer', 'credit', 'mixed'])
  payment_method?: string;

  @ApiPropertyOptional() @IsOptional() @IsNumber() @Min(0) discount_amount?: number;
  @ApiPropertyOptional() @IsOptional() @IsNumber() @Min(0) points_to_redeem?: number;
  @ApiPropertyOptional() @IsOptional() @IsString() notes?: string;
}

export class VoidSaleDto {
  @ApiProperty() @IsString() reason: string;
}

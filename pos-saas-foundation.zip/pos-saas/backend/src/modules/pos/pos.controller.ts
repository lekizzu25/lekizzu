import {
  Controller, Get, Post, Body, Param, Query,
  UseGuards, ParseIntPipe, DefaultValuePipe,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser, CurrentShop, AuthUser } from '../../common/decorators/current-user.decorator';
import { PosService } from './pos.service';
import { CreateSaleDto, VoidSaleDto } from './pos.dto';

@ApiTags('POS')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('pos')
export class PosController {
  constructor(private pos: PosService) {}

  // GET /pos/sales
  @Get('sales')
  @ApiOperation({ summary: 'List sales with pagination' })
  getSales(
    @CurrentShop() shopId: string,
    @Query('limit', new DefaultValuePipe(50), ParseIntPipe) limit: number,
    @Query('offset', new DefaultValuePipe(0), ParseIntPipe) offset: number,
  ) {
    return this.pos.getSales(shopId, limit, offset);
  }

  // GET /pos/sales/:id
  @Get('sales/:id')
  getSale(@CurrentShop() shopId: string, @Param('id') id: string) {
    return this.pos.getSale(shopId, id);
  }

  // POST /pos/sales — main checkout endpoint
  @Post('sales')
  @ApiOperation({ summary: 'Create a new sale (checkout)' })
  createSale(
    @CurrentShop() shopId: string,
    @CurrentUser() user: AuthUser,
    @Body() dto: CreateSaleDto,
  ) {
    return this.pos.createSale(shopId, user.id, dto);
  }

  // POST /pos/sales/:id/void
  @Post('sales/:id/void')
  voidSale(
    @CurrentShop() shopId: string,
    @CurrentUser() user: AuthUser,
    @Param('id') id: string,
    @Body() dto: VoidSaleDto,
  ) {
    return this.pos.voidSale(shopId, id, user.id, dto.reason);
  }

  // GET /pos/products/search?q=cola
  @Get('products/search')
  @ApiOperation({ summary: 'Search products for POS screen' })
  searchProducts(
    @CurrentShop() shopId: string,
    @Query('q') query: string,
  ) {
    return this.pos.searchProducts(shopId, query || '');
  }

  // GET /pos/products/barcode/:barcode
  @Get('products/barcode/:barcode')
  @ApiOperation({ summary: 'Look up product by barcode scan' })
  getByBarcode(
    @CurrentShop() shopId: string,
    @Param('barcode') barcode: string,
  ) {
    return this.pos.getProductByBarcode(shopId, barcode);
  }
}

import {
  Injectable,
  BadRequestException,
  NotFoundException,
} from '@nestjs/common';
import { SupabaseService } from '../../common/supabase/supabase.service';
import { CreateSaleDto } from './pos.dto';

@Injectable()
export class PosService {
  // Points config — 1 point per 10 SAR spent
  private readonly POINTS_PER_SAR = 0.1;

  constructor(private supabase: SupabaseService) {}

  // ── List recent sales ────────────────────────────────────
  async getSales(shopId: string, limit = 50, offset = 0) {
    const { data, error, count } = await this.supabase
      .from('sales')
      .select(`
        *,
        customer:customers(id, name, phone),
        employee:users(id, name),
        items:sale_items(*, product:products(name, barcode))
      `, { count: 'exact' })
      .eq('shop_id', shopId)
      .eq('is_void', false)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) throw new BadRequestException(error.message);
    return { sales: data, total: count };
  }

  // ── Get single sale ──────────────────────────────────────
  async getSale(shopId: string, saleId: string) {
    const { data, error } = await this.supabase
      .from('sales')
      .select(`
        *,
        customer:customers(id, name, phone, email),
        employee:users(id, name),
        items:sale_items(*, product:products(id, name, barcode, unit))
      `)
      .eq('id', saleId)
      .eq('shop_id', shopId)
      .single();

    if (error || !data) throw new NotFoundException('Sale not found');
    return data;
  }

  // ── Create sale (main checkout) ──────────────────────────
  async createSale(shopId: string, employeeId: string, dto: CreateSaleDto) {
    // 1. Validate and fetch products
    const productIds = dto.items.map((i) => i.product_id);
    const { data: products, error: pErr } = await this.supabase
      .from('products')
      .select('id, name, barcode, price, track_inventory')
      .eq('shop_id', shopId)
      .in('id', productIds);

    if (pErr || !products?.length) {
      throw new BadRequestException('Invalid products in order');
    }

    const productMap = Object.fromEntries(products.map((p) => [p.id, p]));

    // 2. Check inventory for tracked products
    if (products.some((p) => p.track_inventory)) {
      const trackedIds = products
        .filter((p) => p.track_inventory)
        .map((p) => p.id);

      const { data: inventory } = await this.supabase
        .from('inventory')
        .select('product_id, quantity')
        .eq('shop_id', shopId)
        .in('product_id', trackedIds);

      const invMap = Object.fromEntries(
        (inventory || []).map((i) => [i.product_id, i.quantity]),
      );

      for (const item of dto.items) {
        const product = productMap[item.product_id];
        if (!product?.track_inventory) continue;
        const available = invMap[item.product_id] ?? 0;
        if (available < item.quantity) {
          throw new BadRequestException(
            `Insufficient stock for "${product.name}". Available: ${available}`,
          );
        }
      }
    }

    // 3. Validate customer & credit
    let customer: Record<string, unknown> | null = null;
    if (dto.customer_id) {
      const { data: c } = await this.supabase
        .from('customers')
        .select('id, name, loyalty_points, credit_balance, credit_limit')
        .eq('id', dto.customer_id)
        .eq('shop_id', shopId)
        .single();
      customer = c;
    }

    // 4. Calculate totals
    const saleItems = dto.items.map((item) => {
      const product = productMap[item.product_id];
      const unitPrice = item.unit_price ?? product.price;
      const discount = item.discount ?? 0;
      const subtotal = unitPrice * item.quantity - discount;
      return {
        product_id: item.product_id,
        product_name: product.name,
        product_barcode: product.barcode,
        quantity: item.quantity,
        unit_price: unitPrice,
        discount,
        subtotal,
      };
    });

    const subtotal = saleItems.reduce((sum, i) => sum + i.subtotal, 0);
    const discountAmount = dto.discount_amount ?? 0;
    const taxAmount = 0; // VAT support in future
    const total = subtotal - discountAmount + taxAmount;

    // 5. Points redemption
    let pointsRedeemed = 0;
    let creditUsed = 0;

    if (dto.points_to_redeem && customer) {
      const maxRedeemable = Math.min(
        dto.points_to_redeem,
        (customer.loyalty_points as number) || 0,
      );
      pointsRedeemed = maxRedeemable;
      // 10 points = 1 SAR
      creditUsed = maxRedeemable / 10;
    }

    // Credit payment
    if (dto.payment_method === 'credit') {
      if (!customer) throw new BadRequestException('Customer required for credit payment');
      const creditBalance = customer.credit_balance as number;
      const creditLimit = customer.credit_limit as number;
      if (creditBalance + total > creditLimit) {
        throw new BadRequestException(
          `Credit limit exceeded. Limit: ${creditLimit}, Current balance: ${creditBalance}`,
        );
      }
    }

    const finalTotal = total - creditUsed;
    const pointsEarned = Math.floor(finalTotal * this.POINTS_PER_SAR);

    // 6. Insert sale
    const { data: sale, error: sErr } = await this.supabase
      .from('sales')
      .insert({
        shop_id: shopId,
        customer_id: dto.customer_id || null,
        employee_id: employeeId,
        subtotal,
        discount_amount: discountAmount,
        tax_amount: taxAmount,
        total: finalTotal,
        payment_method: dto.payment_method || 'cash',
        points_earned: pointsEarned,
        points_redeemed: pointsRedeemed,
        credit_used: creditUsed,
        notes: dto.notes,
      })
      .select()
      .single();

    if (sErr || !sale) throw new BadRequestException('Failed to create sale');

    // 7. Insert sale items
    const itemsWithSaleId = saleItems.map((item) => ({
      ...item,
      sale_id: sale.id,
    }));

    await this.supabase.from('sale_items').insert(itemsWithSaleId);

    // 8. Deduct inventory
    for (const item of dto.items) {
      const product = productMap[item.product_id];
      if (!product.track_inventory) continue;

      await this.supabase.rpc('decrement_inventory', {
        p_shop_id: shopId,
        p_product_id: item.product_id,
        p_quantity: item.quantity,
        p_sale_id: sale.id,
      });
    }

    // 9. Update customer loyalty & credit
    if (customer) {
      const updates: Record<string, unknown> = {
        total_spent: (customer.total_spent as number || 0) + finalTotal,
        visit_count: (customer.visit_count as number || 0) + 1,
        last_visit_at: new Date().toISOString(),
      };

      if (pointsEarned > 0) {
        updates.loyalty_points =
          (customer.loyalty_points as number || 0) + pointsEarned - pointsRedeemed;
      }

      if (dto.payment_method === 'credit') {
        updates.credit_balance =
          (customer.credit_balance as number || 0) + finalTotal;
      }

      await this.supabase
        .from('customers')
        .update(updates)
        .eq('id', dto.customer_id)
        .eq('shop_id', shopId);

      // Log credit transaction
      if (dto.payment_method === 'credit') {
        await this.supabase.from('credit_transactions').insert({
          shop_id: shopId,
          customer_id: dto.customer_id,
          sale_id: sale.id,
          amount: finalTotal,
          type: 'credit',
          balance_after: (customer.credit_balance as number || 0) + finalTotal,
          note: `Sale ${sale.receipt_number}`,
        });
      }

      // Log loyalty transaction
      if (pointsEarned > 0) {
        await this.supabase.from('loyalty_transactions').insert({
          shop_id: shopId,
          customer_id: dto.customer_id,
          sale_id: sale.id,
          points: pointsEarned - pointsRedeemed,
          type: pointsRedeemed > 0 ? 'redeemed' : 'earned',
          balance_after:
            (customer.loyalty_points as number || 0) + pointsEarned - pointsRedeemed,
        });
      }
    }

    // 10. Return full sale
    return this.getSale(shopId, sale.id);
  }

  // ── Void a sale ──────────────────────────────────────────
  async voidSale(shopId: string, saleId: string, userId: string, reason: string) {
    const sale = await this.getSale(shopId, saleId);

    if (sale.is_void) {
      throw new BadRequestException('Sale is already voided');
    }

    await this.supabase
      .from('sales')
      .update({
        is_void: true,
        voided_by: userId,
        voided_at: new Date().toISOString(),
        notes: `VOIDED: ${reason}`,
      })
      .eq('id', saleId)
      .eq('shop_id', shopId);

    // Restore inventory
    for (const item of sale.items) {
      await this.supabase
        .from('inventory')
        .update({ quantity: supabase.rpc('increment', { by: item.quantity }) })
        .eq('product_id', item.product_id)
        .eq('shop_id', shopId);
    }

    return { voided: true, sale_id: saleId };
  }

  // ── Product search for POS screen ────────────────────────
  async searchProducts(shopId: string, query: string) {
    const { data, error } = await this.supabase
      .from('products')
      .select(`
        id, name, name_ar, barcode, sku, price, unit, image_url,
        inventory(quantity)
      `)
      .eq('shop_id', shopId)
      .eq('is_active', true)
      .or(`name.ilike.%${query}%,barcode.eq.${query},sku.ilike.%${query}%`)
      .limit(20);

    if (error) throw new BadRequestException(error.message);
    return data;
  }

  // ── Get product by barcode ────────────────────────────────
  async getProductByBarcode(shopId: string, barcode: string) {
    const { data, error } = await this.supabase
      .from('products')
      .select(`*, inventory(quantity)`)
      .eq('shop_id', shopId)
      .eq('barcode', barcode)
      .eq('is_active', true)
      .single();

    if (error || !data) throw new NotFoundException('Product not found');
    return data;
  }
}

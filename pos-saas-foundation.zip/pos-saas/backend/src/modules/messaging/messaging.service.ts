import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Cron, CronExpression } from '@nestjs/schedule';
import { SupabaseService } from '../../common/supabase/supabase.service';

@Injectable()
export class MessagingService {
  private readonly logger = new Logger(MessagingService.name);

  constructor(
    private supabase: SupabaseService,
    private config: ConfigService,
  ) {}

  // ── Queue a message ──────────────────────────────────────
  async queueMessage(params: {
    shopId: string;
    customerId?: string;
    phone: string;
    messageType: string;
    content: string;
    templateName?: string;
    referenceId?: string;
    referenceType?: string;
  }) {
    const { data } = await this.supabase
      .from('messages')
      .insert({
        shop_id: params.shopId,
        customer_id: params.customerId || null,
        channel: 'whatsapp',
        message_type: params.messageType,
        to_phone: params.phone,
        content: params.content,
        template_name: params.templateName || null,
        reference_id: params.referenceId || null,
        reference_type: params.referenceType || null,
        status: 'pending',
      })
      .select()
      .single();

    return data;
  }

  // ── Send sale receipt via WhatsApp ───────────────────────
  async sendSaleReceipt(sale: Record<string, unknown>, customerPhone: string) {
    const items = (sale.items as Array<Record<string, unknown>> || [])
      .map((i) => `  • ${i.product_name} x${i.quantity} — ${i.subtotal} SAR`)
      .join('\n');

    const content = `🧾 *Receipt from ${(sale as any)?.shop?.name || 'Your Shop'}*

${items}

━━━━━━━━━━━━━━
Total: *${sale.total} SAR*
Payment: ${sale.payment_method}
${sale.points_earned ? `⭐ Points earned: ${sale.points_earned}` : ''}

Receipt #${sale.receipt_number}
Thank you for shopping with us!`;

    return this.queueMessage({
      shopId: sale.shop_id as string,
      customerId: sale.customer_id as string,
      phone: customerPhone,
      messageType: 'receipt',
      content,
      referenceId: sale.id as string,
      referenceType: 'sale',
    });
  }

  // ── Appointment reminder ─────────────────────────────────
  async sendAppointmentReminder(appointment: Record<string, unknown>) {
    const date = new Date(appointment.scheduled_at as string);
    const formattedDate = date.toLocaleDateString('ar-SA');
    const formattedTime = date.toLocaleTimeString('ar-SA', {
      hour: '2-digit', minute: '2-digit',
    });

    const content = `📅 *Appointment Reminder*

Hello ${appointment.customer_name}!

Your appointment is confirmed:
📍 Date: ${formattedDate}
⏰ Time: ${formattedTime}
✂️ Service: ${appointment.service_name || 'Appointment'}

Reply CONFIRM to confirm or CANCEL to cancel.`;

    return this.queueMessage({
      shopId: appointment.shop_id as string,
      customerId: appointment.customer_id as string,
      phone: appointment.customer_phone as string,
      messageType: 'appointment_reminder',
      content,
      referenceId: appointment.id as string,
      referenceType: 'appointment',
    });
  }

  // ── Tailor order ready ───────────────────────────────────
  async sendOrderReady(order: Record<string, unknown>, customerPhone: string) {
    const content = `✅ *Your Order is Ready!*

Hello! Your order #${order.order_number} is ready for pickup.

👗 ${order.description}
📍 Come pick it up at your convenience.

Questions? Reply to this message.`;

    return this.queueMessage({
      shopId: order.shop_id as string,
      customerId: order.customer_id as string,
      phone: customerPhone,
      messageType: 'order_ready',
      content,
      referenceId: order.id as string,
      referenceType: 'tailor_order',
    });
  }

  // ── Loyalty reward notification ──────────────────────────
  async sendLoyaltyReward(params: {
    shopId: string;
    customerId: string;
    phone: string;
    customerName: string;
    points: number;
    totalPoints: number;
  }) {
    const content = `⭐ *Points Update*

Hi ${params.customerName}!
You earned *${params.points} points* on your last purchase.

Total points: *${params.totalPoints}*
${params.totalPoints >= 100 ? '🎁 You can now redeem points for discounts!' : `${100 - params.totalPoints} more points until your first reward.`}`;

    return this.queueMessage({
      shopId: params.shopId,
      customerId: params.customerId,
      phone: params.phone,
      messageType: 'loyalty_reward',
      content,
    });
  }

  // ── Process message queue (runs every minute) ─────────────
  @Cron(CronExpression.EVERY_MINUTE)
  async processMessageQueue() {
    const { data: pending } = await this.supabase
      .from('messages')
      .select('*')
      .eq('status', 'pending')
      .limit(20);

    if (!pending?.length) return;

    for (const message of pending) {
      try {
        await this.sendWhatsAppMessage(message.to_phone, message.content);

        await this.supabase
          .from('messages')
          .update({ status: 'sent', sent_at: new Date().toISOString() })
          .eq('id', message.id);
      } catch (err) {
        this.logger.error(`Failed to send message ${message.id}: ${err.message}`);
        await this.supabase
          .from('messages')
          .update({ status: 'failed', error_message: err.message })
          .eq('id', message.id);
      }
    }
  }

  // ── Actual WhatsApp send (Twilio / WABA) ─────────────────
  private async sendWhatsAppMessage(phone: string, content: string) {
    const provider = this.config.get('WHATSAPP_PROVIDER', 'twilio');

    if (provider === 'twilio') {
      // Twilio WhatsApp API
      const accountSid = this.config.get('TWILIO_ACCOUNT_SID');
      const authToken = this.config.get('TWILIO_AUTH_TOKEN');
      const from = this.config.get('TWILIO_WHATSAPP_FROM');

      if (!accountSid || !authToken) {
        this.logger.warn('Twilio credentials not configured — message not sent');
        return;
      }

      const client = require('twilio')(accountSid, authToken);
      await client.messages.create({
        from: `whatsapp:${from}`,
        to: `whatsapp:${phone}`,
        body: content,
      });
    }

    // Future: support Meta WABA directly
  }

  // ── Scheduled: appointment reminders (runs at 8am daily) ─
  @Cron('0 8 * * *')
  async scheduledAppointmentReminders() {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowStr = tomorrow.toISOString().split('T')[0];

    const { data: appointments } = await this.supabase
      .from('appointments')
      .select(`
        *, 
        customer:customers(phone),
        shop:shops(name)
      `)
      .eq('status', 'confirmed')
      .eq('reminder_sent', false)
      .gte('scheduled_at', `${tomorrowStr}T00:00:00.000Z`)
      .lte('scheduled_at', `${tomorrowStr}T23:59:59.999Z`);

    for (const appt of appointments || []) {
      if (!appt.customer?.phone && !appt.customer_phone) continue;

      await this.sendAppointmentReminder({
        ...appt,
        customer_phone: appt.customer_phone || appt.customer?.phone,
        customer_name: appt.customer_name || appt.customer?.name,
      });

      await this.supabase
        .from('appointments')
        .update({ reminder_sent: true })
        .eq('id', appt.id);
    }
  }
}

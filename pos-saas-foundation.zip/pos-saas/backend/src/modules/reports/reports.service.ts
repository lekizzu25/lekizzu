import { Injectable, BadRequestException } from '@nestjs/common';
import { SupabaseService } from '../../common/supabase/supabase.service';

@Injectable()
export class ReportsService {
  constructor(private supabase: SupabaseService) {}

  // ── Daily sales summary ──────────────────────────────────
  async getDailySummary(shopId: string, date?: string) {
    const targetDate = date || new Date().toISOString().split('T')[0];
    const startOfDay = `${targetDate}T00:00:00.000Z`;
    const endOfDay = `${targetDate}T23:59:59.999Z`;

    const { data: sales, error } = await this.supabase
      .from('sales')
      .select(`
        id, total, subtotal, discount_amount, payment_method,
        points_earned, credit_used, created_at,
        customer:customers(name),
        employee:users(name),
        items:sale_items(quantity, unit_price, subtotal, product_name)
      `)
      .eq('shop_id', shopId)
      .eq('is_void', false)
      .gte('created_at', startOfDay)
      .lte('created_at', endOfDay)
      .order('created_at', { ascending: false });

    if (error) throw new BadRequestException(error.message);

    const totalRevenue = sales.reduce((sum, s) => sum + s.total, 0);
    const totalTransactions = sales.length;
    const averageBasket = totalTransactions > 0 ? totalRevenue / totalTransactions : 0;

    // Payment method breakdown
    const byPaymentMethod = sales.reduce((acc, s) => {
      acc[s.payment_method] = (acc[s.payment_method] || 0) + s.total;
      return acc;
    }, {} as Record<string, number>);

    // Top products today
    const productTotals: Record<string, { name: string; qty: number; revenue: number }> = {};
    for (const sale of sales) {
      for (const item of sale.items || []) {
        if (!productTotals[item.product_name]) {
          productTotals[item.product_name] = { name: item.product_name, qty: 0, revenue: 0 };
        }
        productTotals[item.product_name].qty += item.quantity;
        productTotals[item.product_name].revenue += item.subtotal;
      }
    }
    const topProducts = Object.values(productTotals)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 10);

    return {
      date: targetDate,
      summary: {
        total_revenue: Math.round(totalRevenue * 100) / 100,
        total_transactions: totalTransactions,
        average_basket: Math.round(averageBasket * 100) / 100,
        by_payment_method: byPaymentMethod,
      },
      top_products: topProducts,
      sales,
    };
  }

  // ── Revenue over date range ──────────────────────────────
  async getRevenueChart(shopId: string, startDate: string, endDate: string) {
    const { data, error } = await this.supabase
      .from('sales')
      .select('total, created_at')
      .eq('shop_id', shopId)
      .eq('is_void', false)
      .gte('created_at', `${startDate}T00:00:00.000Z`)
      .lte('created_at', `${endDate}T23:59:59.999Z`)
      .order('created_at');

    if (error) throw new BadRequestException(error.message);

    // Group by date
    const byDate = data.reduce((acc, sale) => {
      const day = sale.created_at.split('T')[0];
      if (!acc[day]) acc[day] = { date: day, revenue: 0, transactions: 0 };
      acc[day].revenue += sale.total;
      acc[day].transactions += 1;
      return acc;
    }, {} as Record<string, { date: string; revenue: number; transactions: number }>);

    return Object.values(byDate).map((d) => ({
      ...d,
      revenue: Math.round(d.revenue * 100) / 100,
    }));
  }

  // ── Inventory alerts ─────────────────────────────────────
  async getLowStockAlerts(shopId: string) {
    const { data, error } = await this.supabase
      .from('inventory')
      .select(`
        quantity, low_stock_threshold,
        product:products(id, name, sku, barcode, unit, category_id)
      `)
      .eq('shop_id', shopId)
      .lt('quantity', this.supabase.db.raw('low_stock_threshold'));

    // Fallback for Supabase (raw not available directly)
    const { data: allInv } = await this.supabase
      .from('inventory')
      .select(`
        quantity, low_stock_threshold,
        product:products(id, name, sku, barcode, unit)
      `)
      .eq('shop_id', shopId);

    const lowStock = (allInv || []).filter(
      (i) => i.quantity <= (i.low_stock_threshold || 5),
    );

    return lowStock.sort((a, b) => a.quantity - b.quantity);
  }

  // ── Top customers ─────────────────────────────────────────
  async getTopCustomers(shopId: string, limit = 10) {
    const { data, error } = await this.supabase
      .from('customers')
      .select('id, name, phone, total_spent, visit_count, loyalty_points, credit_balance')
      .eq('shop_id', shopId)
      .eq('is_active', true)
      .order('total_spent', { ascending: false })
      .limit(limit);

    if (error) throw new BadRequestException(error.message);
    return data;
  }

  // ── Dashboard stats (for home screen) ───────────────────
  async getDashboardStats(shopId: string) {
    const today = new Date().toISOString().split('T')[0];
    const firstOfMonth = new Date(
      new Date().getFullYear(),
      new Date().getMonth(),
      1,
    ).toISOString().split('T')[0];

    const [daily, monthly, customerCount, lowStockCount] = await Promise.all([
      this.getDailySummary(shopId, today),
      this.getRevenueChart(shopId, firstOfMonth, today),
      this.supabase
        .from('customers')
        .select('id', { count: 'exact', head: true })
        .eq('shop_id', shopId)
        .eq('is_active', true),
      this.getLowStockAlerts(shopId),
    ]);

    const monthlyRevenue = monthly.reduce((sum, d) => sum + d.revenue, 0);

    return {
      today: daily.summary,
      monthly_revenue: Math.round(monthlyRevenue * 100) / 100,
      total_customers: customerCount.count || 0,
      low_stock_count: lowStockCount.length,
      revenue_chart: monthly,
    };
  }
}

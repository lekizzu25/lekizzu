import {
  Injectable, NotFoundException, BadRequestException,
} from '@nestjs/common';
import {
  IsString, IsOptional, IsEmail, IsNumber, Min,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { SupabaseService } from '../../common/supabase/supabase.service';

// ── DTOs ──────────────────────────────────────────────────
export class CreateCustomerDto {
  @ApiProperty() @IsString() name: string;
  @ApiPropertyOptional() @IsOptional() @IsString() phone?: string;
  @ApiPropertyOptional() @IsOptional() @IsEmail() email?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() notes?: string;
  @ApiPropertyOptional() @IsOptional() @IsNumber() @Min(0) credit_limit?: number;
}

export class UpdateCustomerDto extends CreateCustomerDto {}

export class RecordRepaymentDto {
  @ApiProperty() @IsNumber() @Min(0.01) amount: number;
  @ApiPropertyOptional() @IsOptional() @IsString() note?: string;
}

export class AdjustLoyaltyDto {
  @ApiProperty() @IsNumber() points: number;
  @ApiProperty() @IsString() reason: string;
}

// ── Service ───────────────────────────────────────────────
@Injectable()
export class CustomersService {
  constructor(private supabase: SupabaseService) {}

  async list(shopId: string, search?: string, limit = 50, offset = 0) {
    let query = this.supabase
      .from('customers')
      .select('*', { count: 'exact' })
      .eq('shop_id', shopId)
      .eq('is_active', true)
      .order('name');

    if (search) {
      query = query.or(
        `name.ilike.%${search}%,phone.ilike.%${search}%`,
      );
    }

    const { data, error, count } = await query.range(offset, offset + limit - 1);
    if (error) throw new BadRequestException(error.message);
    return { customers: data, total: count };
  }

  async findOne(shopId: string, id: string) {
    const { data, error } = await this.supabase
      .from('customers')
      .select('*')
      .eq('id', id)
      .eq('shop_id', shopId)
      .single();

    if (error || !data) throw new NotFoundException('Customer not found');
    return data;
  }

  async create(shopId: string, dto: CreateCustomerDto) {
    const { data, error } = await this.supabase
      .from('customers')
      .insert({ ...dto, shop_id: shopId })
      .select()
      .single();

    if (error) throw new BadRequestException(error.message);
    return data;
  }

  async update(shopId: string, id: string, dto: UpdateCustomerDto) {
    await this.findOne(shopId, id); // throws if not found

    const { data, error } = await this.supabase
      .from('customers')
      .update(dto)
      .eq('id', id)
      .eq('shop_id', shopId)
      .select()
      .single();

    if (error) throw new BadRequestException(error.message);
    return data;
  }

  async getPurchaseHistory(shopId: string, customerId: string, limit = 20) {
    await this.findOne(shopId, customerId);

    const { data } = await this.supabase
      .from('sales')
      .select(`
        id, total, payment_method, receipt_number, created_at, points_earned,
        items:sale_items(product_name, quantity, unit_price, subtotal)
      `)
      .eq('shop_id', shopId)
      .eq('customer_id', customerId)
      .eq('is_void', false)
      .order('created_at', { ascending: false })
      .limit(limit);

    return data;
  }

  async getCreditHistory(shopId: string, customerId: string) {
    const { data } = await this.supabase
      .from('credit_transactions')
      .select('*')
      .eq('shop_id', shopId)
      .eq('customer_id', customerId)
      .order('created_at', { ascending: false });

    return data;
  }

  async recordRepayment(
    shopId: string,
    customerId: string,
    userId: string,
    dto: RecordRepaymentDto,
  ) {
    const customer = await this.findOne(shopId, customerId);

    if (customer.credit_balance <= 0) {
      throw new BadRequestException('Customer has no outstanding credit balance');
    }
    if (dto.amount > customer.credit_balance) {
      throw new BadRequestException(
        `Repayment amount exceeds balance of ${customer.credit_balance}`,
      );
    }

    const newBalance = customer.credit_balance - dto.amount;

    await this.supabase
      .from('customers')
      .update({ credit_balance: newBalance })
      .eq('id', customerId)
      .eq('shop_id', shopId);

    const { data } = await this.supabase
      .from('credit_transactions')
      .insert({
        shop_id: shopId,
        customer_id: customerId,
        amount: dto.amount,
        type: 'repayment',
        balance_after: newBalance,
        note: dto.note || 'Credit repayment',
        recorded_by: userId,
      })
      .select()
      .single();

    return {
      transaction: data,
      new_balance: newBalance,
    };
  }

  async getLoyaltyHistory(shopId: string, customerId: string) {
    const { data } = await this.supabase
      .from('loyalty_transactions')
      .select('*')
      .eq('shop_id', shopId)
      .eq('customer_id', customerId)
      .order('created_at', { ascending: false });

    return data;
  }
}

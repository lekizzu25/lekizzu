-- ============================================================
-- POS SaaS Platform — PostgreSQL Schema
-- Multi-tenant: every record scoped to shop_id
-- ============================================================

-- Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- ENUMS
-- ============================================================

CREATE TYPE shop_type AS ENUM ('baqala', 'barber', 'tailor', 'food_truck', 'kiosk', 'cafe');
CREATE TYPE plan_type AS ENUM ('mobile', 'basic', 'growth', 'pro');
CREATE TYPE user_role AS ENUM ('owner', 'employee', 'admin');
CREATE TYPE payment_method AS ENUM ('cash', 'card', 'transfer', 'credit', 'mixed');
CREATE TYPE message_channel AS ENUM ('whatsapp', 'sms', 'email');
CREATE TYPE message_status AS ENUM ('pending', 'sent', 'delivered', 'failed');
CREATE TYPE appointment_status AS ENUM ('pending', 'confirmed', 'completed', 'cancelled', 'no_show');
CREATE TYPE order_status AS ENUM ('received', 'in_progress', 'ready', 'delivered', 'cancelled');
CREATE TYPE sub_status AS ENUM ('active', 'past_due', 'cancelled', 'trialing');
CREATE TYPE credit_tx_type AS ENUM ('credit', 'repayment');
CREATE TYPE loyalty_tx_type AS ENUM ('earned', 'redeemed', 'adjusted');

-- ============================================================
-- CORE TABLES
-- ============================================================

-- Shops (tenants)
CREATE TABLE shops (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name            TEXT NOT NULL,
  type            shop_type NOT NULL,
  plan            plan_type NOT NULL DEFAULT 'basic',
  -- JSON array of enabled module keys e.g. ["pos","inventory","credit","appointments"]
  enabled_modules JSONB NOT NULL DEFAULT '["pos","customers","reports"]',
  phone           TEXT,
  address         TEXT,
  city            TEXT,
  logo_url        TEXT,
  currency        TEXT NOT NULL DEFAULT 'SAR',
  timezone        TEXT NOT NULL DEFAULT 'Asia/Riyadh',
  is_active       BOOLEAN NOT NULL DEFAULT true,
  trial_ends_at   TIMESTAMPTZ,
  owner_id        UUID,  -- references users.id (set after user creation)
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Users (employees + owners)
CREATE TABLE users (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  shop_id         UUID NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
  auth_id         UUID UNIQUE,  -- Supabase auth.users.id
  role            user_role NOT NULL DEFAULT 'employee',
  name            TEXT NOT NULL,
  email           TEXT,
  phone           TEXT,
  pin             TEXT,         -- 4-digit PIN for quick POS login
  is_active       BOOLEAN NOT NULL DEFAULT true,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Add FK from shops.owner_id → users.id
ALTER TABLE shops ADD CONSTRAINT shops_owner_id_fkey
  FOREIGN KEY (owner_id) REFERENCES users(id);

-- ============================================================
-- CUSTOMERS (CRM)
-- ============================================================

CREATE TABLE customers (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  shop_id         UUID NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
  name            TEXT NOT NULL,
  phone           TEXT,
  email           TEXT,
  notes           TEXT,
  loyalty_points  INTEGER NOT NULL DEFAULT 0,
  credit_balance  DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  credit_limit    DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  total_spent     DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  visit_count     INTEGER NOT NULL DEFAULT 0,
  last_visit_at   TIMESTAMPTZ,
  is_active       BOOLEAN NOT NULL DEFAULT true,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Credit transactions (baqala notebook replacement)
CREATE TABLE credit_transactions (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  shop_id         UUID NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
  customer_id     UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  sale_id         UUID,  -- references sales.id if linked to a sale
  amount          DECIMAL(10,2) NOT NULL,
  type            credit_tx_type NOT NULL,
  balance_after   DECIMAL(10,2) NOT NULL,
  note            TEXT,
  recorded_by     UUID REFERENCES users(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Loyalty transactions
CREATE TABLE loyalty_transactions (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  shop_id         UUID NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
  customer_id     UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  sale_id         UUID,
  points          INTEGER NOT NULL,  -- positive = earned, negative = redeemed
  type            loyalty_tx_type NOT NULL,
  balance_after   INTEGER NOT NULL,
  note            TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- PRODUCTS & INVENTORY
-- ============================================================

CREATE TABLE categories (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  shop_id         UUID NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
  name            TEXT NOT NULL,
  color           TEXT DEFAULT '#6366f1',
  icon            TEXT,
  sort_order      INTEGER DEFAULT 0,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE products (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  shop_id         UUID NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
  category_id     UUID REFERENCES categories(id),
  name            TEXT NOT NULL,
  name_ar         TEXT,           -- Arabic name
  sku             TEXT,
  barcode         TEXT,
  description     TEXT,
  price           DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  cost_price      DECIMAL(10,2),  -- for profit tracking
  unit            TEXT DEFAULT 'piece',  -- piece, kg, liter, etc.
  image_url       TEXT,
  is_active       BOOLEAN NOT NULL DEFAULT true,
  track_inventory BOOLEAN NOT NULL DEFAULT true,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(shop_id, barcode),
  UNIQUE(shop_id, sku)
);

CREATE TABLE inventory (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  shop_id         UUID NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
  product_id      UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  quantity        DECIMAL(10,3) NOT NULL DEFAULT 0,
  low_stock_threshold DECIMAL(10,3) DEFAULT 5,
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(shop_id, product_id)
);

-- Inventory adjustment log
CREATE TABLE inventory_logs (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  shop_id         UUID NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
  product_id      UUID NOT NULL REFERENCES products(id),
  user_id         UUID REFERENCES users(id),
  sale_id         UUID,
  quantity_change DECIMAL(10,3) NOT NULL,
  quantity_after  DECIMAL(10,3) NOT NULL,
  reason          TEXT,  -- 'sale', 'adjustment', 'restock', 'return'
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- POS / SALES
-- ============================================================

CREATE TABLE sales (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  shop_id         UUID NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
  customer_id     UUID REFERENCES customers(id),
  employee_id     UUID REFERENCES users(id),
  subtotal        DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  tax_amount      DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  total           DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  payment_method  payment_method NOT NULL DEFAULT 'cash',
  points_earned   INTEGER DEFAULT 0,
  points_redeemed INTEGER DEFAULT 0,
  credit_used     DECIMAL(10,2) DEFAULT 0.00,
  notes           TEXT,
  receipt_number  TEXT,
  is_void         BOOLEAN NOT NULL DEFAULT false,
  voided_by       UUID REFERENCES users(id),
  voided_at       TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE sale_items (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sale_id         UUID NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
  product_id      UUID REFERENCES products(id),
  product_name    TEXT NOT NULL,   -- snapshot name in case product changes
  product_barcode TEXT,
  quantity        DECIMAL(10,3) NOT NULL DEFAULT 1,
  unit_price      DECIMAL(10,2) NOT NULL,
  discount        DECIMAL(10,2) DEFAULT 0.00,
  subtotal        DECIMAL(10,2) NOT NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Add FK from credit_transactions.sale_id
ALTER TABLE credit_transactions ADD CONSTRAINT credit_tx_sale_id_fkey
  FOREIGN KEY (sale_id) REFERENCES sales(id);
ALTER TABLE loyalty_transactions ADD CONSTRAINT loyalty_tx_sale_id_fkey
  FOREIGN KEY (sale_id) REFERENCES sales(id);
ALTER TABLE inventory_logs ADD CONSTRAINT inv_log_sale_id_fkey
  FOREIGN KEY (sale_id) REFERENCES sales(id);

-- ============================================================
-- BARBER MODULE — Appointments
-- ============================================================

CREATE TABLE services (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  shop_id         UUID NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
  name            TEXT NOT NULL,
  name_ar         TEXT,
  duration_mins   INTEGER NOT NULL DEFAULT 30,
  price           DECIMAL(10,2) NOT NULL,
  is_active       BOOLEAN NOT NULL DEFAULT true,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE appointments (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  shop_id         UUID NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
  customer_id     UUID REFERENCES customers(id),
  employee_id     UUID REFERENCES users(id),   -- the barber
  service_id      UUID REFERENCES services(id),
  customer_name   TEXT,   -- if walk-in without profile
  customer_phone  TEXT,
  scheduled_at    TIMESTAMPTZ NOT NULL,
  duration_mins   INTEGER NOT NULL DEFAULT 30,
  status          appointment_status NOT NULL DEFAULT 'pending',
  price           DECIMAL(10,2),
  commission_pct  DECIMAL(5,2) DEFAULT 0,   -- employee commission %
  notes           TEXT,
  reminder_sent   BOOLEAN DEFAULT false,
  sale_id         UUID REFERENCES sales(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TAILOR MODULE — Orders
-- ============================================================

CREATE TABLE tailor_orders (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  shop_id         UUID NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
  customer_id     UUID REFERENCES customers(id),
  employee_id     UUID REFERENCES users(id),
  order_number    TEXT,
  description     TEXT NOT NULL,
  garment_type    TEXT,           -- thobe, suit, dress, etc.
  -- Measurements stored flexibly as JSONB
  -- { chest: 110, waist: 95, length: 145, sleeve: 65, ... }
  measurements    JSONB,
  fabric_details  TEXT,
  special_notes   TEXT,
  price           DECIMAL(10,2),
  deposit_paid    DECIMAL(10,2) DEFAULT 0.00,
  due_date        DATE,
  status          order_status NOT NULL DEFAULT 'received',
  image_urls      JSONB DEFAULT '[]',
  reminder_sent   BOOLEAN DEFAULT false,
  sale_id         UUID REFERENCES sales(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- MESSAGING (WhatsApp Automation)
-- ============================================================

CREATE TABLE messages (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  shop_id         UUID NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
  customer_id     UUID REFERENCES customers(id),
  channel         message_channel NOT NULL DEFAULT 'whatsapp',
  -- type: 'receipt', 'loyalty_reward', 'promotion', 'appointment_reminder',
  --       'order_ready', 'credit_statement'
  message_type    TEXT NOT NULL,
  to_phone        TEXT NOT NULL,
  content         TEXT NOT NULL,
  template_name   TEXT,
  status          message_status NOT NULL DEFAULT 'pending',
  provider_id     TEXT,           -- external message ID from Twilio/WABA
  error_message   TEXT,
  reference_id    UUID,           -- sale_id, appointment_id, etc.
  reference_type  TEXT,           -- 'sale', 'appointment', 'tailor_order'
  sent_at         TIMESTAMPTZ,
  delivered_at    TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- SUBSCRIPTIONS & BILLING
-- ============================================================

CREATE TABLE subscriptions (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  shop_id               UUID NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
  plan                  plan_type NOT NULL,
  status                sub_status NOT NULL DEFAULT 'trialing',
  current_period_start  TIMESTAMPTZ,
  current_period_end    TIMESTAMPTZ,
  stripe_customer_id    TEXT,
  stripe_subscription_id TEXT,
  stripe_price_id       TEXT,
  cancel_at_period_end  BOOLEAN DEFAULT false,
  trial_end             TIMESTAMPTZ,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- INDEXES (for performance)
-- ============================================================

-- Shops
CREATE INDEX idx_shops_owner ON shops(owner_id);

-- Users
CREATE INDEX idx_users_shop ON users(shop_id);
CREATE INDEX idx_users_auth ON users(auth_id);

-- Customers
CREATE INDEX idx_customers_shop ON customers(shop_id);
CREATE INDEX idx_customers_phone ON customers(shop_id, phone);

-- Products
CREATE INDEX idx_products_shop ON products(shop_id);
CREATE INDEX idx_products_barcode ON products(shop_id, barcode);
CREATE INDEX idx_products_sku ON products(shop_id, sku);

-- Inventory
CREATE INDEX idx_inventory_shop ON inventory(shop_id);
CREATE INDEX idx_inventory_product ON inventory(product_id);

-- Sales
CREATE INDEX idx_sales_shop ON sales(shop_id);
CREATE INDEX idx_sales_customer ON sales(customer_id);
CREATE INDEX idx_sales_employee ON sales(employee_id);
CREATE INDEX idx_sales_created ON sales(shop_id, created_at DESC);

-- Sale Items
CREATE INDEX idx_sale_items_sale ON sale_items(sale_id);
CREATE INDEX idx_sale_items_product ON sale_items(product_id);

-- Appointments
CREATE INDEX idx_appointments_shop ON appointments(shop_id);
CREATE INDEX idx_appointments_employee ON appointments(employee_id);
CREATE INDEX idx_appointments_scheduled ON appointments(shop_id, scheduled_at);

-- Tailor Orders
CREATE INDEX idx_tailor_orders_shop ON tailor_orders(shop_id);
CREATE INDEX idx_tailor_orders_customer ON tailor_orders(customer_id);
CREATE INDEX idx_tailor_orders_due ON tailor_orders(shop_id, due_date);

-- Messages
CREATE INDEX idx_messages_shop ON messages(shop_id);
CREATE INDEX idx_messages_status ON messages(status) WHERE status = 'pending';

-- ============================================================
-- ROW-LEVEL SECURITY (Supabase)
-- ============================================================

ALTER TABLE shops ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE sale_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE tailor_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

-- Policy: users can only see data from their own shop
-- The NestJS API uses service_role key (bypasses RLS)
-- These RLS policies protect direct Supabase client access

CREATE POLICY "Users see own shop" ON shops
  FOR ALL USING (id = (
    SELECT shop_id FROM users WHERE auth_id = auth.uid() LIMIT 1
  ));

CREATE POLICY "Shop data isolation" ON customers
  FOR ALL USING (shop_id = (
    SELECT shop_id FROM users WHERE auth_id = auth.uid() LIMIT 1
  ));

-- Apply same pattern to other tables
CREATE POLICY "Shop data isolation" ON products
  FOR ALL USING (shop_id = (
    SELECT shop_id FROM users WHERE auth_id = auth.uid() LIMIT 1
  ));

CREATE POLICY "Shop data isolation" ON sales
  FOR ALL USING (shop_id = (
    SELECT shop_id FROM users WHERE auth_id = auth.uid() LIMIT 1
  ));

-- ============================================================
-- FUNCTIONS & TRIGGERS
-- ============================================================

-- Auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_updated_at BEFORE UPDATE ON shops
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON customers
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON products
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON appointments
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON tailor_orders
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER set_updated_at BEFORE UPDATE ON subscriptions
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Auto-generate receipt numbers
CREATE OR REPLACE FUNCTION generate_receipt_number()
RETURNS TRIGGER AS $$
DECLARE
  shop_prefix TEXT;
  counter     INTEGER;
BEGIN
  SELECT UPPER(LEFT(name, 3)) INTO shop_prefix FROM shops WHERE id = NEW.shop_id;
  SELECT COUNT(*) + 1 INTO counter FROM sales WHERE shop_id = NEW.shop_id;
  NEW.receipt_number = shop_prefix || '-' || LPAD(counter::TEXT, 6, '0');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER auto_receipt_number BEFORE INSERT ON sales
  FOR EACH ROW EXECUTE FUNCTION generate_receipt_number();

-- Auto-generate tailor order numbers
CREATE OR REPLACE FUNCTION generate_order_number()
RETURNS TRIGGER AS $$
DECLARE
  counter INTEGER;
BEGIN
  SELECT COUNT(*) + 1 INTO counter FROM tailor_orders WHERE shop_id = NEW.shop_id;
  NEW.order_number = 'ORD-' || LPAD(counter::TEXT, 5, '0');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER auto_order_number BEFORE INSERT ON tailor_orders
  FOR EACH ROW EXECUTE FUNCTION generate_order_number();
